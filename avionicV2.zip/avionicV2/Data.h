#ifndef Data_h
#define Data_h
#define NBDATA 9
struct Data {
  uint16_t altitude;
  double orientation [3];
  float acceleration [3];
  int temperature;
  uint8_t battery_level=0;
};

#endif
