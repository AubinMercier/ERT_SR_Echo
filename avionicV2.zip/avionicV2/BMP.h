#ifndef BMP_H
#define BMP_H
#include "Data.h"
void recordBMPData(Data *d);
void printBMPData(Data const&d);
void setupBMP();

#endif
